Du wirst die Datei manifest.json in diesem Archiv bemerkt haben.
Die Datei manifest.json könnte für das spätere Wiederherstellen des Backups aus diesem Archiv benötigt werden.
Bitte lasse die manifest.json unberührt an ihrem Platz. Du kannst sie ansonsten einfach ignorieren.
